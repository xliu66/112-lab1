from django.apps import AppConfig


class RetalsConfig(AppConfig):
    name = 'retals'
